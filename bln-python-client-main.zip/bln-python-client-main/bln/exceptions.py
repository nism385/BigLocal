class APIException(Exception):
    """An error raised when accessing the biglocalnews.org API."""

    pass
